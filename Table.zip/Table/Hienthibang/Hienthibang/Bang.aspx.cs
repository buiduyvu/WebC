﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace Hienthibang
{
    public partial class Bang : System.Web.UI.Page
    {
        protected void submit(object sender, EventArgs e)
        {
            int row, numrows, numcells, j, i;
            row = 0;
            numrows = int.Parse(rows1.Value);
            numcells = int.Parse(cells1.Value);
            for (j = 1; j <= numrows; j++)
            {
                HtmlTableRow r = new HtmlTableRow();
                row = row + 1;
                for(i = 1; i <= numcells; i++)
                {
                    HtmlTableCell c = new HtmlTableCell();
                    c.Controls.Add(new LiteralControl("Dòng" +j+",cột"+i));
                    r.Cells.Add(c);
                }
                t1.Rows.Add(r);
                t1.Visible=true;
            }
        }
    }
}
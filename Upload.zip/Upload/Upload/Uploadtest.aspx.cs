﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Upload
{
    public partial class Uploadtest : System.Web.UI.Page
    {
        protected void submit(object sender, EventArgs e)
        {
            fname.InnerHtml = MyFile.PostedFile.FileName;
            clength.InnerHtml = MyFile.PostedFile.ContentLength.ToString();
            MyFile.PostedFile.SaveAs("C:\\winform\\website\\Upload\\Upload\\FileUpload\\" + MyFile.PostedFile.FileName);
        }
    }
}
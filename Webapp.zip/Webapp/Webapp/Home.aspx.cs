﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Webapp
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Label1.Text = "Ngày giờ hiện hành";
            //lblThoiGian.Text = DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss");
            
        }
        protected void submit(object sender, EventArgs e)
        {
            string sResult = "";
            if (red.Checked) sResult = "đỏ,";
            if (green.Checked) sResult = sResult + "xanh lục,";
            if (blue.Checked)
                sResult = sResult + "xanh dương";
            p1.InnerHtml = "Bạn thích màu:" + sResult;
            red.Checked = false;
            green.Checked = false;
            blue.Checked = false;
            
        }
       
    }
}